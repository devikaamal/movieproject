from django.contrib import admin

from movieapp.models import Movietb

# Register your models here.

admin.site.register(Movietb)
